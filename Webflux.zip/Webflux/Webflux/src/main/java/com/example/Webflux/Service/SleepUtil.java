package com.example.Webflux.Service;

public class SleepUtil {

	public static void sleepSeconds(int seconds)
	{
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
